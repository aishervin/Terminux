import base64
import json
import os
import sys
import tempfile
import threading
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import app


@contextmanager
def local_server(workspace):
    with patch.object(app, "WORKSPACE_DIR", workspace):
        server = app.LocalServer(("127.0.0.1", 0), app.Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            yield f"http://127.0.0.1:{server.server_address[1]}"
        finally:
            server.shutdown()
            server.server_close()


def http_request(url, path, body=None):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    request = Request(url + path, data=data, headers={"Content-Type": "application/json"}, method="POST" if data is not None else "GET")
    try:
        response = urlopen(request)
    except HTTPError as error:
        return error.code, error.headers, error.read()
    with response:
        return response.status, response.headers, response.read()


class AgentCoreTests(unittest.TestCase):
    def test_payload_declares_shell_tool(self):
        payload = app.build_gemini_payload([{"role": "user", "parts": [{"text": "hello"}]}])
        declarations = payload["tools"][0]["functionDeclarations"]
        names = {item["name"] for item in declarations}
        self.assertTrue({"run_shell", "write_file", "github_api", "github_create_repo", "github_publish_workspace", "cloudflare_api"} <= names)

    def test_command_returns_exit_status_and_output(self):
        with patch.object(app, "WORKSPACE_DIR", Path.cwd()):
            result = app.execute_command("printf agent-test")
        self.assertEqual(result["exit_code"], 0)
        self.assertEqual(result["output"], "agent-test")

    def test_command_output_is_capped(self):
        with patch.object(app, "WORKSPACE_DIR", Path.cwd()), patch.object(app, "MAX_OUTPUT_CHARS", 5):
            result = app.execute_command("printf 123456789")
        self.assertTrue(result["output"].startswith("12345"))
        self.assertIn("کوتاه شد", result["output"])

    def test_empty_command_is_rejected(self):
        result = app.execute_command("  ")
        self.assertNotEqual(result["exit_code"], 0)

    def test_provider_tokens_are_removed_from_shell_environment(self):
        with patch.object(app, "WORKSPACE_DIR", Path.cwd()), patch.dict(os.environ, {"GITHUB_TOKEN": "hidden-test-token", "CLOUDFLARE_API_TOKEN": "hidden-cf-token"}):
            result = app.execute_command("printf '%s:%s' \"${GITHUB_TOKEN-unset}\" \"${CLOUDFLARE_API_TOKEN-unset}\"")
        self.assertEqual(result["output"], "unset:unset")

    def test_provider_tokens_enter_shell_only_after_opt_in(self):
        settings = {"pass_tokens_to_shell": True, "github_token": "gh-cli-token", "cloudflare_token": "cf-cli-token"}
        with patch.object(app, "WORKSPACE_DIR", Path.cwd()), patch.dict(app.CONFIG, settings):
            result = app.execute_command("printf '%s:%s' \"$GH_TOKEN\" \"$CLOUDFLARE_API_TOKEN\"")
        self.assertEqual(result["output"], "gh-cli-token:cf-cli-token")

    def test_workspace_read_write_and_escape_guard(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with patch.object(app, "WORKSPACE_DIR", root):
                result = app.write_workspace_file("src/main.py", "print('hello')")
                self.assertTrue(result["ok"])
                self.assertEqual(app.read_workspace_file("src/main.py")["content"], "print('hello')")
                with self.assertRaises(ValueError):
                    app.workspace_path("../outside.txt")

    def test_upload_sanitizes_names_uses_private_random_paths_and_enforces_size(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            payload = base64.b64encode(b"hello").decode("ascii")
            with patch.object(app, "WORKSPACE_DIR", root):
                first = app.save_upload("../../notes.txt", "text/plain", payload)
                second = app.save_upload("../../notes.txt", "text/plain", payload)
                self.assertEqual(first["name"], "notes.txt")
                self.assertNotEqual(first["path"], second["path"])
                self.assertEqual((root / first["path"]).read_bytes(), b"hello")
                self.assertTrue(first["path"].startswith(".terminux-uploads/"))
                with self.assertRaises(ValueError):
                    app.save_upload("bad.txt", "text/plain", "not-base64!")
                too_large = base64.b64encode(b"x" * (app.MAX_UPLOAD_BYTES + 1)).decode("ascii")
                with self.assertRaises(ValueError):
                    app.save_upload("large.bin", "application/octet-stream", too_large)
            if os.name == "posix":
                uploads = root / app.UPLOADS_DIR_NAME
                self.assertEqual(uploads.stat().st_mode & 0o777, 0o700)
                self.assertEqual((root / first["path"]).stat().st_mode & 0o777, 0o600)

    def test_upload_endpoint_rejects_oversized_decoded_file_and_tampered_path(self):
        with tempfile.TemporaryDirectory() as temporary, local_server(Path(temporary)) as url:
            status, _headers, body = http_request(url, "/api/upload", {
                "name": "../receipt.txt", "mimeType": "text/plain", "data": base64.b64encode(b"distinct file bytes").decode("ascii"),
            })
            self.assertEqual(status, 201)
            response = json.loads(body)
            self.assertEqual(set(response), {"file"})
            self.assertEqual(set(response["file"]), {"name", "path", "size", "mimeType"})
            self.assertEqual(response["file"]["name"], "receipt.txt")
            self.assertNotIn("distinct file bytes", body.decode("utf-8"))
            self.assertNotIn(base64.b64encode(b"distinct file bytes").decode("ascii"), body.decode("utf-8"))
            listing = app.list_workspace(app.UPLOADS_DIR_NAME)
            self.assertNotIn({"name": ".metadata", "type": "directory"}, listing["entries"])
            visible_file = next(item for item in listing["entries"] if item["path"] == response["file"]["path"])
            self.assertEqual(visible_file["name"], "receipt.txt")

            oversized = base64.b64encode(b"x" * (app.MAX_UPLOAD_BYTES + 1)).decode("ascii")
            status, _headers, _body = http_request(url, "/api/upload", {
                "name": "large.bin", "mimeType": "application/octet-stream", "data": oversized,
            })
            self.assertEqual(status, 400)

            saved = app.save_upload("safe.txt", "text/plain", base64.b64encode(b"ok").decode("ascii"))
            forged = {**saved, "path": ".terminux-uploads/../../outside.txt"}
            with self.assertRaises(ValueError):
                app._validated_upload(forged)

    def test_workspace_files_endpoint_lists_and_serves_safe_downloads(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "notes.txt").write_text("hello", encoding="utf-8")
            (root / "large.dat").write_bytes(b"123456")
            (root / "preview.html").write_text("<script>unsafe()</script>", encoding="utf-8")
            with local_server(root) as url, patch.object(app, "MAX_WORKSPACE_FILE_BYTES", 5):
                status, _headers, body = http_request(url, "/api/files")
                self.assertEqual(status, 200)
                listing = json.loads(body)
                self.assertEqual(listing["path"], ".")
                self.assertIn({"name": "notes.txt", "type": "file"}, listing["entries"])

                status, headers, body = http_request(url, "/api/file?path=notes.txt")
                self.assertEqual(status, 200)
                self.assertEqual(body, b"hello")
                self.assertEqual(headers.get_content_type(), "text/plain")
                self.assertTrue(headers["Content-Disposition"].startswith("inline;"))

                with patch.object(app, "MAX_WORKSPACE_FILE_BYTES", 1024):
                    status, headers, _body = http_request(url, "/api/file?path=preview.html")
                self.assertEqual(status, 200)
                self.assertIn("sandbox", headers["Content-Security-Policy"])

                status, headers, _body = http_request(url, "/api/file?path=notes.txt&download=1")
                self.assertEqual(status, 200)
                self.assertTrue(headers["Content-Disposition"].startswith("attachment;"))

                status, _headers, _body = http_request(url, "/api/file?path=../../outside.txt")
                self.assertEqual(status, 400)
                status, _headers, _body = http_request(url, "/api/file?path=large.dat")
                self.assertEqual(status, 413)

    def test_attachment_only_chat_is_accepted_and_keeps_metadata_not_content(self):
        with tempfile.TemporaryDirectory() as temporary, local_server(Path(temporary)) as url:
            metadata = app.save_upload("photo.png", "image/png", base64.b64encode(b"png-bytes").decode("ascii"))
            started = threading.Event()

            def controlled_worker(message, attachments):
                self.assertEqual(message, "")
                self.assertEqual(attachments, [metadata])
                started.set()

            with patch.object(app, "RUNNING", False), patch.object(app, "EVENTS", []), patch.object(app, "HISTORY", []), \
                    patch.object(app, "save_events"), patch.object(app, "save_history"), patch.object(app, "run_agent", side_effect=controlled_worker):
                status, _headers, body = http_request(url, "/api/chat", {"attachments": [metadata]})
                self.assertEqual(status, 202)
                self.assertTrue(started.wait(2))
                self.assertEqual(app.EVENTS[0]["attachments"], [metadata])

    def test_image_attachment_is_hydrated_only_for_active_gemini_request(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            raw = b"fake-image-binary"
            with patch.object(app, "WORKSPACE_DIR", root):
                metadata = app.save_upload("image.png", "image/png", base64.b64encode(raw).decode("ascii"))
                prior_turn = {"role": "user", "parts": [
                    {"text": "earlier reference"}, {"terminuxAttachment": metadata},
                ]}
                current_turn = {"role": "user", "parts": [
                    {"text": "describe this"}, {"terminuxAttachment": metadata},
                ]}
                history = [prior_turn, current_turn]
                active = app.build_gemini_payload(history, [metadata])
                older = app.build_gemini_payload(history)

            self.assertFalse(any("inlineData" in part for part in active["contents"][0]["parts"]))
            active_parts = active["contents"][1]["parts"]
            inline = next(part["inlineData"] for part in active_parts if "inlineData" in part)
            self.assertEqual(inline, {"mimeType": "image/png", "data": base64.b64encode(raw).decode("ascii")})
            self.assertNotIn("inlineData", json.dumps(older))
            self.assertIn(metadata["path"], json.dumps(older))
            self.assertNotIn(base64.b64encode(raw).decode("ascii"), json.dumps(history))

    def test_source_attachment_with_generic_mime_is_included_as_text(self):
        with tempfile.TemporaryDirectory() as temporary:
            with patch.object(app, "WORKSPACE_DIR", Path(temporary)):
                metadata = app.save_upload("main.py", "application/octet-stream", base64.b64encode(b"print('hi')").decode("ascii"))
                payload = app.build_gemini_payload([{"role": "user", "parts": [
                    {"text": "Review this file."}, {"terminuxAttachment": metadata},
                ]}], [metadata])
        self.assertEqual(metadata["mimeType"], "text/x-python")
        self.assertIn("print('hi')", json.dumps(payload))

    def test_credentials_and_history_are_saved_with_private_permissions(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with patch.object(app, "CONFIG_DIR", root), patch.object(app, "CONFIG_FILE", root / "config.json"), patch.object(app, "HISTORY_FILE", root / "history.json"), patch.object(app, "HISTORY", [{"role": "user", "parts": [{"text": "continue"}]}]):
                with patch.dict(app.CONFIG, {"api_key": "gemini-test", "github_token": "github-test", "cloudflare_token": "cloudflare-test", "model": "gemini-test-model"}):
                    app.CONFIG["pass_tokens_to_shell"] = True
                    app.save_config()
                app.save_history()
                settings = json.loads((root / "config.json").read_text(encoding="utf-8"))
                self.assertEqual(settings["github_token"], "github-test")
                self.assertEqual(settings["cloudflare_token"], "cloudflare-test")
                self.assertTrue(settings["pass_tokens_to_shell"])
                if os.name == "posix":
                    self.assertEqual((root / "config.json").stat().st_mode & 0o777, 0o600)
                    self.assertEqual(root.stat().st_mode & 0o777, 0o700)

    def test_persisted_history_reloads_for_the_next_run(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with patch.object(app, "CONFIG_DIR", root), patch.object(app, "HISTORY_FILE", root / "history.json"), patch.object(app, "HISTORY", [{"role": "user", "parts": [{"text": "resume project"}]}]) as history:
                app.save_history()
                history.clear()
                app.load_history()
                self.assertEqual(history[0]["parts"][0]["text"], "resume project")

    def test_settings_api_saves_tokens_but_never_returns_them(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            server = app.LocalServer(("127.0.0.1", 0), app.Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f"http://127.0.0.1:{server.server_address[1]}"
            try:
                with patch.object(app, "CONFIG_DIR", root), patch.object(app, "CONFIG_FILE", root / "config.json"), patch.dict(app.CONFIG, {}, clear=True):
                    body = json.dumps({"apiKey":"AQ.synthetic-test-key","githubToken":"github-secret","cloudflareToken":"cloudflare-secret","passTokensToShell":True,"model":"gemini-test"}).encode()
                    request = Request(url + "/api/config", data=body, headers={"Content-Type":"application/json"}, method="POST")
                    saved = json.load(urlopen(request))
                    visible = json.load(urlopen(url + "/api/config"))
                    persisted = json.loads((root / "config.json").read_text(encoding="utf-8"))
                self.assertTrue(saved["githubConfigured"] and saved["cloudflareConfigured"])
                self.assertTrue(saved["configured"])
                self.assertTrue(saved["passTokensToShell"])
                self.assertEqual(persisted["api_key"], "AQ.synthetic-test-key")
                self.assertNotIn("github-secret", json.dumps(visible))
                self.assertNotIn("cloudflare-secret", json.dumps(visible))
                self.assertNotIn("AQ.synthetic-test-key", json.dumps(visible))
            finally:
                server.shutdown()
                server.server_close()

    def test_provider_token_stays_in_header_not_tool_result(self):
        class FakeResponse:
            status = 200

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def read(self, _size):
                return b'{"login":"agent"}'

        with patch.dict(app.CONFIG, {"github_token": "test-token-secret"}), patch.object(app, "urlopen", return_value=FakeResponse()) as mocked:
            result = app.provider_api("github", "GET", "/user")
        request = mocked.call_args.args[0]
        self.assertEqual(request.full_url, "https://api.github.com/user")
        self.assertEqual(request.get_header("Authorization"), "Bearer test-token-secret")
        self.assertNotIn("test-token-secret", json.dumps(result))

    def test_provider_rejects_absolute_or_traversal_paths(self):
        with patch.dict(app.CONFIG, {"github_token": "test-token"}):
            self.assertIn("error", app.provider_api("github", "GET", "https://example.com/user"))
            self.assertIn("error", app.provider_api("github", "GET", "/repos/a/../b"))

    def test_publish_workspace_builds_single_commit_and_skips_env(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "README.md").write_text("# Demo", encoding="utf-8")
            (root / ".env").write_text("SECRET=hidden", encoding="utf-8")
            (root / ".env.production").write_text("SECRET=also-hidden", encoding="utf-8")
            (root / "icon.png").write_bytes(b"\x89PNG\r\n\x1a\n")
            (root / ".terminux-uploads").mkdir()
            (root / ".terminux-uploads" / "private.txt").write_text("must stay local", encoding="utf-8")
            calls = []

            def fake_api(_provider, method, path, body=None):
                calls.append((method, path, body))
                if method == "GET" and path == "/repos/alice/demo":
                    return {"success": True, "data": {"default_branch": "main"}}
                if method == "GET" and path.endswith("/git/ref/heads/main"):
                    return {"success": False, "status": 404, "data": {}}
                if method == "POST" and path.endswith("/git/blobs"):
                    return {"success": True, "data": {"sha": "binary-blob-sha"}}
                if method == "POST" and path.endswith("/git/trees"):
                    return {"success": True, "data": {"sha": "tree-sha"}}
                if method == "POST" and path.endswith("/git/commits"):
                    return {"success": True, "data": {"sha": "commit-sha", "html_url": "https://github.com/alice/demo/commit/commit-sha"}}
                if method == "POST" and path.endswith("/git/refs"):
                    return {"success": True, "data": {}}
                self.fail(f"Unexpected API request: {method} {path}")

            with patch.object(app, "WORKSPACE_DIR", root), patch.object(app, "provider_api", side_effect=fake_api):
                result = app.github_publish_workspace({"owner": "alice", "repo": "demo", "message": "Initial commit"})

            self.assertTrue(result["success"])
            self.assertEqual(result["files_committed"], 2)
            tree_request = next(body for method, path, body in calls if method == "POST" and path.endswith("/git/trees"))
            self.assertEqual({entry["path"] for entry in tree_request["tree"]}, {"README.md", "icon.png"})
            self.assertEqual(next(entry["sha"] for entry in tree_request["tree"] if entry["path"] == "icon.png"), "binary-blob-sha")
            self.assertNotIn("SECRET=hidden", json.dumps(tree_request))
            self.assertNotIn("SECRET=also-hidden", json.dumps(tree_request))

    def test_publish_updates_existing_branch_without_force_push(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "main.py").write_text("print('updated')", encoding="utf-8")
            calls = []

            def fake_api(_provider, method, path, body=None):
                calls.append((method, path, body))
                if method == "GET" and path == "/repos/alice/demo":
                    return {"success": True, "data": {"default_branch": "main"}}
                if method == "GET" and path.endswith("/git/ref/heads/main"):
                    return {"success": True, "data": {"object": {"sha": "old-commit"}}}
                if method == "GET" and path.endswith("/git/commits/old-commit"):
                    return {"success": True, "data": {"tree": {"sha": "old-tree"}}}
                if method == "POST" and path.endswith("/git/trees"):
                    return {"success": True, "data": {"sha": "new-tree"}}
                if method == "POST" and path.endswith("/git/commits"):
                    return {"success": True, "data": {"sha": "new-commit", "html_url": "https://github.com/alice/demo/commit/new-commit"}}
                if method == "PATCH" and path.endswith("/git/refs/heads/main"):
                    return {"success": True, "data": {}}
                self.fail(f"Unexpected API request: {method} {path}")

            with patch.object(app, "WORKSPACE_DIR", root), patch.object(app, "provider_api", side_effect=fake_api):
                result = app.github_publish_workspace({"owner": "alice", "repo": "demo", "message": "Update"})

            self.assertTrue(result["success"])
            update = next(call for call in calls if call[0] == "PATCH")
            self.assertFalse(update[2]["force"])
            self.assertEqual(update[2]["sha"], "new-commit")


class MultiProviderTests(unittest.TestCase):
    def test_catalog_lists_all_providers_with_models(self):
        catalog = app.model_catalog()
        ids = {provider["id"] for provider in catalog["providers"]}
        self.assertTrue({"gemini", "mistral", "deepseek", "openrouter", "pollinations"} <= ids)
        for provider in catalog["providers"]:
            self.assertTrue(provider["models"])
            self.assertTrue(provider["label"])

    def test_free_provider_is_configured_without_any_key(self):
        with patch.dict(app.CONFIG, {"provider": "pollinations", "model": "openai"}):
            self.assertTrue(app.provider_is_configured("pollinations"))

    def test_paid_provider_requires_its_key(self):
        with patch.dict(app.CONFIG, {"mistral_api_key": ""}, clear=False):
            self.assertFalse(app.provider_is_configured("mistral"))
        with patch.dict(app.CONFIG, {"mistral_api_key": "k"}):
            self.assertTrue(app.provider_is_configured("mistral"))

    def test_openai_request_converts_history_and_declares_tools(self):
        with patch.dict(app.CONFIG, {"provider": "mistral", "model": "mistral-small-latest"}):
            history = [
                {"role": "user", "parts": [{"text": "list files"}]},
                {"role": "model", "parts": [{"functionCall": {"name": "list_workspace", "args": {"path": "."}}}]},
                {"role": "user", "parts": [{"functionResponse": {"name": "list_workspace", "response": {"entries": []}}}]},
            ]
            body = app.build_openai_request(history)
        self.assertEqual(body["model"], "mistral-small-latest")
        messages = body["messages"]
        self.assertEqual(messages[0]["role"], "system")
        self.assertEqual(messages[1], {"role": "user", "content": "list files"})
        assistant = messages[2]
        self.assertEqual(assistant["role"], "assistant")
        self.assertEqual(assistant["tool_calls"][0]["function"]["name"], "list_workspace")
        tool_message = messages[3]
        self.assertEqual(tool_message["role"], "tool")
        self.assertEqual(tool_message["tool_call_id"], assistant["tool_calls"][0]["id"])
        tool_names = {tool["function"]["name"] for tool in body["tools"]}
        self.assertTrue({"run_shell", "write_file", "github_api", "cloudflare_api"} <= tool_names)
        self.assertEqual(body["tools"][0]["function"]["parameters"]["type"], "object")

    def test_openai_response_converts_back_to_gemini_parts(self):
        payload = {
            "choices": [{
                "message": {
                    "content": "done",
                    "tool_calls": [{"id": "call_1", "type": "function", "function": {"name": "run_shell", "arguments": "{\"command\":\"ls\"}"}}],
                }
            }]
        }
        gemini = app.openai_response_to_gemini(payload)
        parts = gemini["candidates"][0]["content"]["parts"]
        self.assertEqual(parts[0]["text"], "done")
        self.assertEqual(parts[1]["functionCall"]["name"], "run_shell")
        self.assertEqual(parts[1]["functionCall"]["args"], {"command": "ls"})

    def test_openai_response_without_choices_raises(self):
        with self.assertRaises(RuntimeError):
            app.openai_response_to_gemini({"error": {"message": "quota"}})

    def test_call_model_dispatches_to_the_active_provider(self):
        with patch.dict(app.CONFIG, {"provider": "pollinations", "model": "openai"}), \
                patch.object(app, "call_openai_compatible", return_value={"candidates": []}) as mocked:
            app.call_model([])
            mocked.assert_called_once()

    def test_config_endpoint_saves_provider_and_extra_keys_safely(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            server = app.LocalServer(("127.0.0.1", 0), app.Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f"http://127.0.0.1:{server.server_address[1]}"
            try:
                with patch.object(app, "CONFIG_DIR", root), patch.object(app, "CONFIG_FILE", root / "config.json"), patch.dict(app.CONFIG, {}, clear=True):
                    body = json.dumps({"provider": "deepseek", "model": "deepseek-v4-flash", "deepseekApiKey": "sk-secret", "passTokensToShell": False}).encode()
                    request = Request(url + "/api/config", data=body, headers={"Content-Type": "application/json"}, method="POST")
                    saved = json.load(urlopen(request))
                    visible = json.load(urlopen(url + "/api/config"))
                    persisted = json.loads((root / "config.json").read_text(encoding="utf-8"))
                self.assertEqual(saved["provider"], "deepseek")
                self.assertTrue(saved["providerConfigured"])
                self.assertEqual(persisted["deepseek_api_key"], "sk-secret")
                self.assertNotIn("sk-secret", json.dumps(visible))
            finally:
                server.shutdown()
                server.server_close()

    def test_config_endpoint_rejects_unknown_provider_and_bad_model(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            server = app.LocalServer(("127.0.0.1", 0), app.Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f"http://127.0.0.1:{server.server_address[1]}"
            try:
                with patch.object(app, "CONFIG_DIR", root), patch.object(app, "CONFIG_FILE", root / "config.json"):
                    status, _headers, _body = http_request(url, "/api/config", {"provider": "nope", "model": "x"})
                    self.assertEqual(status, 400)
                    status, _headers, _body = http_request(url, "/api/config", {"provider": "mistral", "model": "bad model!"})
                    self.assertEqual(status, 400)
            finally:
                server.shutdown()
                server.server_close()

    def test_shell_environment_strips_model_provider_keys(self):
        with patch.object(app, "WORKSPACE_DIR", Path.cwd()), patch.dict(os.environ, {"MISTRAL_API_KEY": "m", "DEEPSEEK_API_KEY": "d", "OPENROUTER_API_KEY": "o"}):
            result = app.execute_command("printf '%s:%s:%s' \"${MISTRAL_API_KEY-unset}\" \"${DEEPSEEK_API_KEY-unset}\" \"${OPENROUTER_API_KEY-unset}\"")
        self.assertEqual(result["output"], "unset:unset:unset")

    def test_models_endpoint_returns_catalog(self):
        with local_server(Path.cwd()) as url:
            status, _headers, body = http_request(url, "/api/models")
            self.assertEqual(status, 200)
            catalog = json.loads(body)
            self.assertIn("providers", catalog)


class ConnectorToolsTests(unittest.TestCase):
    def test_payload_declares_connector_tools(self):
        payload = app.build_gemini_payload([{"role": "user", "parts": [{"text": "hi"}]}])
        names = {item["name"] for item in payload["tools"][0]["functionDeclarations"]}
        self.assertTrue({"linear_api", "hf_api", "gmail_api", "drive_api", "mcp_call"} <= names)

    def test_linear_api_requires_key(self):
        with patch.dict(app.CONFIG, {"linear_api_key": ""}):
            self.assertIn("error", app.linear_api({"query": "{ viewer { id } }"}))

    def test_linear_api_sends_graphql_request(self):
        captured = {}

        def fake_http(method, url, headers, body=None):
            captured.update({"method": method, "url": url, "headers": headers, "body": body})
            return {"status": 200, "success": True, "data": {"data": {"viewer": {"id": "u1"}}}, "truncated": False}

        with patch.dict(app.CONFIG, {"linear_api_key": "lin_key"}), patch.object(app, "_http_json", side_effect=fake_http):
            result = app.linear_api({"query": "query { viewer { id } }", "variables": {"a": 1}})
        self.assertTrue(result["success"])
        self.assertEqual(captured["url"], "https://api.linear.app/graphql")
        self.assertEqual(captured["headers"]["Authorization"], "lin_key")
        self.assertEqual(captured["body"], {"query": "query { viewer { id } }", "variables": {"a": 1}})

    def test_hf_api_rejects_absolute_paths(self):
        with patch.dict(app.CONFIG, {"hf_token": "hf_x"}):
            self.assertIn("error", app.hf_api({"path": "https://evil.example.com"}))
            self.assertIn("error", app.hf_api({"path": "../secret"}))

    def test_gmail_send_requires_settings(self):
        with patch.dict(app.CONFIG, {"gmail_address": "", "gmail_app_password": ""}):
            self.assertIn("error", app.gmail_api({"action": "send", "to": "x@y.com", "body": "hi"}))

    def test_drive_api_requires_refresh_token(self):
        with patch.dict(app.CONFIG, {"drive_refresh_token": "", "drive_access_token": ""}):
            self.assertIn("error", app.drive_api({"path": "files/list"}))

    def test_drive_api_refreshes_and_retries_on_401(self):
        calls = []
        responses = [
            {"status": 401, "success": False, "data": {}, "truncated": False},
            {"status": 200, "success": True, "data": {"files": []}, "truncated": False},
        ]

        def fake_access():
            return "tok"

        def fake_http(method, url, headers, body=None):
            calls.append((headers["Authorization"], url))
            return responses.pop(0)

        with patch.dict(app.CONFIG, {"drive_refresh_token": "r"}), \
                patch.object(app, "drive_access_token", side_effect=fake_access), \
                patch.object(app, "_http_json", side_effect=fake_http):
            result = app.drive_api({"path": "files/list"})
        self.assertTrue(result["success"])
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0][1], calls[1][1])

    def test_mcp_call_unknown_server(self):
        with patch.dict(app.CONFIG, {"mcp_servers": {}}):
            self.assertIn("error", app.mcp_call({"server": "nope", "tool": "x"}))

    def test_mcp_call_runs_local_stdio_server(self):
        server_script = (
            "import json,sys\n"
            "while True:\n"
            "    line=sys.stdin.readline()\n"
            "    if not line: break\n"
            "    msg=json.loads(line)\n"
            "    if msg.get('method')=='tools/call':\n"
            "        out={'jsonrpc':'2.0','id':msg['id'],'result':{'content':[{'type':'text','text':'ok: '+msg['params']['arguments']['x']}]}}\n"
            "    elif msg.get('id') is not None:\n"
            "        out={'jsonrpc':'2.0','id':msg['id'],'result':{}}\n"
            "    else:\n"
            "        continue\n"
            "    sys.stdout.write(json.dumps(out)+'\\n')\n"
            "    sys.stdout.flush()\n"
        )
        with patch.object(app, "WORKSPACE_DIR", Path.cwd()), \
                patch.dict(app.CONFIG, {"mcp_servers": {"echo": {"command": [sys.executable, "-c", server_script]}}}):
            result = app.mcp_call({"server": "echo", "tool": "echo", "arguments": {"x": "hello"}})
        self.assertTrue(result["success"])
        self.assertIn("ok: hello", json.dumps(result))

    def test_connector_writes_need_approval(self):
        self.assertTrue(app.tool_needs_approval("gmail_api", {"action": "send"}))
        self.assertFalse(app.tool_needs_approval("gmail_api", {"action": "search"}))
        self.assertTrue(app.tool_needs_approval("linear_api", {"query": "mutation { issueCreate { success } }"}))
        self.assertFalse(app.tool_needs_approval("linear_api", {"query": "{ viewer { id } }"}))
        self.assertTrue(app.tool_needs_approval("hf_api", {"method": "POST", "path": "api/x"}))
        self.assertFalse(app.tool_needs_approval("hf_api", {"method": "GET", "path": "api/x"}))

    def test_shell_environment_strips_connector_keys(self):
        with patch.object(app, "WORKSPACE_DIR", Path.cwd()), patch.dict(os.environ, {"LINEAR_API_KEY": "l", "HF_TOKEN": "h", "GMAIL_APP_PASSWORD": "g"}):
            result = app.execute_command("printf '%s:%s:%s' \"${LINEAR_API_KEY-unset}\" \"${HF_TOKEN-unset}\" \"${GMAIL_APP_PASSWORD-unset}\"")
        self.assertEqual(result["output"], "unset:unset:unset")

    def test_config_endpoint_saves_connector_keys_and_mcp_servers(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            server = app.LocalServer(("127.0.0.1", 0), app.Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f"http://127.0.0.1:{server.server_address[1]}"
            try:
                with patch.object(app, "CONFIG_DIR", root), patch.object(app, "CONFIG_FILE", root / "config.json"), patch.dict(app.CONFIG, {}, clear=True):
                    body = {
                        "provider": "gemini",
                        "linearApiKey": "lin_1",
                        "hfToken": "hf_1",
                        "gmailAddress": "a@gmail.com",
                        "gmailAppPassword": "pw123",
                        "mcpServers": {"echo": {"command": ["echo", "hi"]}},
                    }
                    _s, _h, _b = http_request(url, "/api/config", body)
                    visible = json.loads(http_request(url, "/api/config")[2])
                    persisted = json.loads((root / "config.json").read_text(encoding="utf-8"))
                self.assertEqual(persisted["linear_api_key"], "lin_1")
                self.assertEqual(persisted["hf_token"], "hf_1")
                self.assertEqual(persisted["gmail_app_password"], "pw123")
                self.assertEqual(persisted["mcp_servers"], {"echo": {"command": ["echo", "hi"]}})
                self.assertNotIn("lin_1", json.dumps(visible))
                self.assertNotIn("hf_1", json.dumps(visible))
                self.assertNotIn("pw123", json.dumps(visible))
                self.assertEqual(visible["mcpServers"], {"echo": {"command": ["echo", "hi"]}})
            finally:
                server.shutdown()
                server.server_close()

    def test_config_endpoint_rejects_bad_mcp_server_names(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            server = app.LocalServer(("127.0.0.1", 0), app.Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f"http://127.0.0.1:{server.server_address[1]}"
            try:
                with patch.object(app, "CONFIG_DIR", root), patch.object(app, "CONFIG_FILE", root / "config.json"):
                    status, _headers, _body = http_request(url, "/api/config", {"mcpServers": {"bad name!": {"command": "x"}}})
                    self.assertEqual(status, 400)
            finally:
                server.shutdown()
                server.server_close()


class SpeechTests(unittest.TestCase):
    def test_speak_text_requires_termux_api(self):
        with patch("app.shutil.which", return_value=None):
            with self.assertRaises(RuntimeError):
                app.speak_text("سلام")

    def test_speak_text_spawns_termux_tts_speak_in_persian(self):
        calls = []
        with patch("app.shutil.which", return_value="/usr/bin/termux-tts-speak"), \
                patch.object(app.subprocess, "Popen", side_effect=lambda args, **_kwargs: calls.append(args)):
            app.speak_text("  سلام دنیا  ")
        self.assertEqual(calls, [["/usr/bin/termux-tts-speak", "-l", "fa", "سلام دنیا"]])

    def test_speak_text_is_capped(self):
        calls = []
        with patch("app.shutil.which", return_value="/usr/bin/termux-tts-speak"), \
                patch.object(app.subprocess, "Popen", side_effect=lambda args, **_kwargs: calls.append(args)):
            app.speak_text("ا" * 9000)
        self.assertEqual(len(calls[0][3]), 4000)

    def test_stop_speaking_without_binary(self):
        with patch("app.shutil.which", return_value=None):
            self.assertFalse(app.stop_speaking())

    def test_speak_endpoint_validates_text(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            server = app.LocalServer(("127.0.0.1", 0), app.Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f"http://127.0.0.1:{server.server_address[1]}"
            try:
                with patch("app.shutil.which", return_value=None):
                    empty_status, _h, _b = http_request(url, "/api/speak", {"text": "   "})
                    wrong_status, _h, _b = http_request(url, "/api/speak", {"text": 42})
                    missing_status, _h, _b = http_request(url, "/api/speak", {"text": "سلام"})
                    stop_status, stop_body = http_request(url, "/api/speak", {"stop": True})[0], json.loads(http_request(url, "/api/speak", {"stop": True})[2])
                self.assertEqual(empty_status, 400)
                self.assertEqual(wrong_status, 400)
                self.assertEqual(missing_status, 500)
                self.assertEqual(stop_status, 200)
                self.assertFalse(stop_body["stopped"])
            finally:
                server.shutdown()
                server.server_close()

    def test_speak_endpoint_calls_speak_text(self):
        spoken = []
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            server = app.LocalServer(("127.0.0.1", 0), app.Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f"http://127.0.0.1:{server.server_address[1]}"
            try:
                with patch.object(app, "speak_text", side_effect=spoken.append):
                    status, _h, body = http_request(url, "/api/speak", {"text": "پاسخ نهایی"})
                self.assertEqual(status, 200)
                self.assertEqual(spoken, ["پاسخ نهایی"])
                self.assertTrue(json.loads(body)["ok"])
            finally:
                server.shutdown()
                server.server_close()

    def test_state_reports_tts_availability(self):
        with tempfile.TemporaryDirectory() as workspace:
            with local_server(Path(workspace)) as url, patch("app.shutil.which", return_value=None):
                _s, _h, body = http_request(url, "/api/state?after=0")
                self.assertFalse(json.loads(body)["ttsAvailable"])
            with local_server(Path(workspace)) as url, patch("app.shutil.which", return_value="/usr/bin/termux-tts-speak"):
                _s, _h, body = http_request(url, "/api/state?after=0")
                self.assertTrue(json.loads(body)["ttsAvailable"])


class SelfRepairTests(unittest.TestCase):
    def test_self_update_requires_git_checkout(self):
        with tempfile.TemporaryDirectory() as temporary:
            with patch.object(app, "APP_DIR", Path(temporary)):
                result = app.self_update()
        self.assertIn("error", result)

    def test_self_update_runs_git_pull_and_reports_output(self):
        class FakeCompleted:
            returncode = 0
            stdout = "Already up to date."
            stderr = ""
        ran = []
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / ".git").mkdir()
            with patch.object(app, "APP_DIR", root), patch.object(app.subprocess, "run", side_effect=lambda args, **_kwargs: ran.append(args) or FakeCompleted()):
                result = app.self_update()
        self.assertTrue(result["ok"])
        self.assertEqual(ran[0][1:3], ["-C", str(root)])
        self.assertIn("output", result)

    def test_self_update_reports_git_failure(self):
        class FakeCompleted:
            returncode = 1
            stdout = ""
            stderr = "merge conflict"
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / ".git").mkdir()
            with patch.object(app, "APP_DIR", root), patch.object(app.subprocess, "run", return_value=FakeCompleted()):
                result = app.self_update()
        self.assertIn("error", result)

    def test_restart_server_spawns_waiter_and_schedules_shutdown(self):
        timers = []

        class FakeTimer:
            def __init__(self, interval, function):
                self.interval, self.function = interval, function

            def start(self):
                timers.append(self.interval)
                self.function()
        killed = []
        popped = []
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with patch.object(app, "APP_DIR", root), patch.object(app, "LAUNCH_ARGS", [sys.executable, str(root / "app.py"), "--port", "9000"]), patch.object(app.threading, "Timer", FakeTimer), patch("app.os.kill", side_effect=lambda pid, sig: killed.append((pid, sig))), patch.object(app.subprocess, "Popen", side_effect=lambda args, **_kwargs: popped.append(args)):
                result = app.restart_server()
            script = (root / "terminux-restart.sh").read_text(encoding="utf-8")
        self.assertTrue(result["ok"])
        self.assertEqual(timers, [3.0])
        self.assertEqual(killed, [(os.getpid(), 2)])
        self.assertEqual(popped[0][0], "bash")
        self.assertIn("app.py", script)
        self.assertIn("--port 9000", script)
        self.assertNotIn("--open-browser", script)

    def test_self_repair_tools_need_approval(self):
        self.assertTrue(app.tool_needs_approval("self_update", {}))
        self.assertTrue(app.tool_needs_approval("restart_server", {}))

    def test_dispatch_routes_self_repair_tools(self):
        self.assertIn("error", app.dispatch_tool("no_such_tool", {}))
        with patch.object(app, "self_update", return_value={"ok": True}) as fake_update:
            result = app.dispatch_tool("self_update", {})
            fake_update.assert_called_once()
        self.assertTrue(result["ok"])


class ModelMigrationTests(unittest.TestCase):
    def test_retired_model_is_migrated_and_persisted(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with patch.object(app, "CONFIG_DIR", root), patch.object(app, "CONFIG_FILE", root / "config.json"), patch.object(app, "add_event"), patch.dict(app.CONFIG, {"provider": "gemini", "model": "gemini-3.8-flash"}, clear=True):
                app.migrate_retired_model()
                self.assertEqual(app.CONFIG["model"], "gemini-3.5-flash")
                app.migrate_retired_model()
                self.assertEqual(app.CONFIG["model"], "gemini-3.5-flash")
                persisted = json.loads((root / "config.json").read_text(encoding="utf-8"))
                self.assertEqual(persisted["model"], "gemini-3.5-flash")

    def test_current_model_is_left_alone(self):
        with patch.object(app, "add_event"), patch.dict(app.CONFIG, {"provider": "gemini", "model": "gemini-3.5-flash"}, clear=True):
            app.migrate_retired_model()
        self.assertEqual(app.CONFIG["model"], "gemini-3.5-flash")

    def test_every_retired_model_maps_to_a_catalog_model(self):
        catalog = {m["id"] for info in app.PROVIDERS.values() for m in info["models"]}
        for replacement in app.RETIRED_MODELS.values():
            self.assertIn(replacement, catalog)


class LiveModelTests(unittest.TestCase):
    def test_current_model_maps_retired_and_falls_back_to_default(self):
        with patch.dict(app.CONFIG, {"provider": "gemini", "model": "gemini-3.8-flash"}, clear=True):
            self.assertEqual(app.current_model(), "gemini-3.5-flash")
        with patch.dict(app.CONFIG, {"provider": "gemini", "model": None}, clear=True):
            self.assertEqual(app.current_model(), "gemini-3.5-flash")
        with patch.dict(app.CONFIG, {"provider": "pollinations", "model": "deepseek"}, clear=True):
            self.assertEqual(app.current_model(), "openai")

    def test_openai_request_uses_current_model(self):
        with patch.dict(app.CONFIG, {"provider": "gemini", "model": "gemini-3.8-flash"}, clear=True):
            payload = app.build_openai_request([])
        self.assertEqual(payload["model"], "gemini-3.5-flash")

    def test_pollinations_models_falls_back_when_network_fails(self):
        with patch("app.urlopen", side_effect=OSError("offline")):
            models = app.pollinations_models()
        self.assertEqual(models, app.PROVIDERS["pollinations"]["models"])

    def test_pollinations_models_fetches_live_list_and_caches(self):
        class FakeResponse:
            def read(self):
                return json.dumps([{"name": "foo"}, {"name": "bar"}]).encode("utf-8")

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False
        with patch.object(app, "POLLINATIONS_CACHE", {"at": 0.0, "models": []}), patch("app.urlopen", return_value=FakeResponse()):
            models = app.pollinations_models()
            self.assertEqual([m["id"] for m in models], ["foo", "bar"])
            self.assertTrue(app.POLLINATIONS_CACHE["models"])


class OpenAIErrorFormattingTests(unittest.TestCase):
    def test_formats_mistral_validation_error_detail(self):
        detail = app._format_api_error({
            "detail": [
                {"loc": ["body", "tools", 0], "msg": "Field required", "type": "missing"},
                {"loc": ["body", "messages", 1], "msg": "Invalid message", "type": "value_error"},
            ]
        })
        self.assertIn("body.tools.0: Field required", detail)
        self.assertIn("body.messages.1: Invalid message", detail)

    def test_formats_openai_error_message(self):
        self.assertEqual(
            app._format_api_error({"error": {"message": "Invalid model"}}),
            "Invalid model",
        )

    def test_never_displays_none_for_empty_error(self):
        self.assertEqual(app._format_api_error({"error": None}), "")


class OpenAIResponseCompatibilityTests(unittest.TestCase):
    def test_openai_content_parts_are_flattened_to_text(self):
        result = app.openai_response_to_gemini({
            "choices": [{"message": {"content": [
                {"type": "output_text", "text": "سلام "},
                {"type": "text", "text": "دنیا"},
            ]}}]
        })
        self.assertEqual(
            result["candidates"][0]["content"]["parts"],
            [{"text": "سلام دنیا"}],
        )

    def test_openai_empty_response_has_actionable_message(self):
        result = app.openai_response_to_gemini({
            "choices": [{"message": {"content": None, "tool_calls": []}}]
        })
        self.assertIn("دوباره تلاش کن", result["candidates"][0]["content"]["parts"][0]["text"])


class HistoryEndpointTests(unittest.TestCase):
    def test_history_endpoint_returns_messages_events_and_runtime_state(self):
        with local_server(Path.cwd()) as url, \
                patch.object(app, "HISTORY", [{"role": "user", "parts": [{"text": "hi"}]}]), \
                patch.object(app, "EVENTS", [{"id": 1, "type": "user", "text": "hi"}]), \
                patch.object(app, "PENDING_APPROVAL", None), \
                patch.object(app, "RUNNING", False):
            status, _headers, body = http_request(url, "/api/history")
        self.assertEqual(status, 200)
        payload = json.loads(body)
        self.assertEqual(payload["messages"][0]["parts"][0]["text"], "hi")
        self.assertEqual(payload["events"][0]["id"], 1)
        self.assertFalse(payload["running"])


if __name__ == "__main__":
    unittest.main()


class OpenRouterModelTests(unittest.TestCase):
    def test_model_id_with_colon_is_accepted_by_validator(self):
        import re
        self.assertTrue(re.fullmatch(r"[A-Za-z0-9._/:+-]{1,120}", "nvidia/nemotron-3.5-lightning:free"))

    def test_openrouter_live_catalog_keeps_only_free_tool_models(self):
        class FakeResponse:
            def read(self):
                return json.dumps({"data": [
                    {"id": "a/free-tools:free", "name": "A", "pricing": {"prompt": "0", "completion": "0"}, "supported_parameters": ["tools"]},
                    {"id": "b/free-notools:free", "name": "B", "pricing": {"prompt": "0", "completion": "0"}, "supported_parameters": []},
                    {"id": "c/paid", "name": "C", "pricing": {"prompt": "0.1", "completion": "0.2"}, "supported_parameters": ["tools"]},
                ]}).encode("utf-8")
            def __enter__(self): return self
            def __exit__(self, *args): return False
        app.OPENROUTER_CACHE.update({"at": 0.0, "models": []})
        with patch("app.urlopen", return_value=FakeResponse()):
            ids = [m["id"] for m in app.openrouter_models()]
        app.OPENROUTER_CACHE.update({"at": 0.0, "models": []})
        self.assertEqual(ids, ["openrouter/free", "a/free-tools:free"])

    def test_openrouter_falls_back_to_static_list_offline(self):
        app.OPENROUTER_CACHE.update({"at": 0.0, "models": []})
        with patch("app.urlopen", side_effect=OSError("offline")):
            self.assertEqual(app.openrouter_models(), app.PROVIDERS["openrouter"]["models"])

    def test_openrouter_request_has_free_router_fallback(self):
        with patch.dict(app.CONFIG, {"provider": "openrouter", "model": "nvidia/nemotron-3.5-lightning:free"}, clear=True):
            body = app.build_openai_request([])
        self.assertEqual(body["models"], ["nvidia/nemotron-3.5-lightning:free", "openrouter/free"])
