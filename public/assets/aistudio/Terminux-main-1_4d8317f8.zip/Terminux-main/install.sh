#!/data/data/com.termux/files/usr/bin/bash
# Terminux installer (English-only on purpose: Termux cannot shape Persian text).
set -uo pipefail

REPOSITORY="https://github.com/aishervin/Terminux.git"
BRANCH="main"
APP_DIR="$HOME/.local/share/terminux"
TMP="$(mktemp -d)"
LOG="$TMP/install.log"
TOTAL=3
BAR_WIDTH=24

if [ -t 1 ] && [ "${TERM:-dumb}" != "dumb" ]; then
  RESET=$'\033[0m'; BOLD=$'\033[1m'; DIM=$'\033[2m'
  ORANGE=$'\033[38;5;208m'; GREEN=$'\033[38;5;114m'; RED=$'\033[38;5;203m'; WHITE=$'\033[38;5;255m'
  HIDE=$'\033[?25l'; SHOW=$'\033[?25h'; CLEAR_LINE=$'\r\033[2K'
else
  RESET=''; BOLD=''; DIM=''; ORANGE=''; GREEN=''; RED=''; WHITE=''; HIDE=''; SHOW=''; CLEAR_LINE=$'\r'
fi

cleanup() { printf '%s' "$SHOW$RESET"; rm -rf "$TMP"; }
trap cleanup EXIT
trap 'printf "\n"; exit 130' INT TERM

if ! command -v pkg >/dev/null 2>&1; then
  printf 'This installer must run inside Termux (F-Droid or GitHub build).\n' >&2
  exit 1
fi

bar() {  # bar <percent>
  local percent=$1 filled empty i out=""
  filled=$(( percent * BAR_WIDTH / 100 ))
  empty=$(( BAR_WIDTH - filled ))
  for ((i = 0; i < filled; i++)); do out+="#"; done
  for ((i = 0; i < empty; i++)); do out+="-"; done
  printf '%s[%s]%s %3d%%' "$ORANGE" "$out" "$RESET" "$percent"
}

banner() {
  printf '\n  %s%sTERMINUX%s  %sTermux installer%s\n' "$BOLD" "$ORANGE" "$RESET" "$DIM" "$RESET"
  printf '  %s------------------------------------------%s\n\n' "$DIM" "$RESET"
}

# step <index> <label> <command...>
step() {
  local index=$1 label=$2; shift 2
  local done_pct=$(( (index - 1) * 100 / TOTAL )) pid frames='|/-\' tick=0
  "$@" >>"$LOG" 2>&1 &
  pid=$!
  printf '%s' "$HIDE"
  while kill -0 "$pid" 2>/dev/null; do
    printf '%s  %s%s%s  [%d/%d] %s   ' "$CLEAR_LINE" "$ORANGE" "${frames:tick%4:1}" "$RESET" "$index" "$TOTAL" "$label"
    bar "$done_pct"
    tick=$(( tick + 1 ))
    sleep 0.15
  done
  if wait "$pid"; then
    printf '%s  %sOK%s  [%d/%d] %s\n' "$CLEAR_LINE" "$GREEN" "$RESET" "$index" "$TOTAL" "$label"
  else
    printf '%s  %sXX%s  [%d/%d] %s\n' "$CLEAR_LINE" "$RED" "$RESET" "$index" "$TOTAL" "$label" >&2
    printf '\n  %sLast lines of the log:%s\n' "$RED" "$RESET" >&2
    tail -n 12 "$LOG" | sed 's/^/    /' >&2
    printf '\n  Check your internet connection and run the installer again.\n' >&2
    exit 1
  fi
}

install_packages() {
  export DEBIAN_FRONTEND=noninteractive
  pkg update -y -o Dpkg::Options::="--force-confnew" || true
  pkg install -y -o Dpkg::Options::="--force-confnew" python git curl termux-tools termux-api
}

fetch_app() {
  if [ -d "$APP_DIR/.git" ]; then
    git -C "$APP_DIR" fetch --depth 1 origin "$BRANCH" && git -C "$APP_DIR" reset --hard "origin/$BRANCH"
  else
    rm -rf "$APP_DIR"
    mkdir -p "$(dirname "$APP_DIR")"
    git clone --depth 1 -b "$BRANCH" "$REPOSITORY" "$APP_DIR"
  fi
}

verify_app() {
  command -v python >/dev/null 2>&1 && [ -f "$APP_DIR/app.py" ] && python -m py_compile "$APP_DIR/app.py"
}

banner
step 1 "Installing packages (python, git)" install_packages
step 2 "Downloading Terminux" fetch_app
step 3 "Checking installation" verify_app

printf '%s  ' "$CLEAR_LINE"; bar 100; printf '\n\n'
printf '  %s%sInstalled successfully.%s\n' "$BOLD" "$GREEN" "$RESET"
printf '  %sLocal address:%s %shttp://127.0.0.1:8765%s\n' "$DIM" "$RESET" "$ORANGE" "$RESET"
printf '  %sPress Ctrl+C to stop.%s\n' "$DIM" "$RESET"
printf '  %sTip: install the Termux:API app to enable text-to-speech.%s\n\n' "$DIM" "$RESET"
printf '%s' "$SHOW$RESET"
exec python "$APP_DIR/app.py" --open-browser
