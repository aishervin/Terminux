# Terminux

Exclusive SHΞN™ made

Install / update (inside Termux):

```
curl -fsSL https://raw.githubusercontent.com/aishervin/Terminux/main/install.sh | bash
```
